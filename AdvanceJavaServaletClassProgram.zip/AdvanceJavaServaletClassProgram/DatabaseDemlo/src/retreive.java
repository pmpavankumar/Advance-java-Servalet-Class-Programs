

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class retreive
 */
@WebServlet("/retreive")
public class retreive extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
try {
			
			//String url ="jdbc:mysql://localhost:3307/advjava?autoReconnect=true&useSSL=false";
			//String user="root";
			//String dbpassword = "tiger";
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			
			Connection con = DriverManager.getConnection(dbproperties.URL,dbproperties.USER,dbproperties.DBPASSWORD);
			
			out.println("connected");
			
			PreparedStatement ps = con.prepareStatement("select * from userdetails");
			ResultSet rs = ps.executeQuery();
			
			out.print("<h2>Data Fetched From DB</h2>"); 
			
			out.print("<table>");	
			while(rs.next()) {
				
				out.print("<tr>");
				out.print("<td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td>");
				out.print("<tr>");
			}
			out.print("</table>");
				
			}
		   catch(Exception e) {
			   System.out.println(e);
		   }
			
	}

}
