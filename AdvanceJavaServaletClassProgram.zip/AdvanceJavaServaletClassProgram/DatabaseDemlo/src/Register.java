

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String address = request.getParameter("address");
		
		
		out.println("username is "+username);
		out.println("password is "+password);
		out.println("gender is "+gender);
		out.println("address is "+address);
		
		try {
			
			//String url ="jdbc:mysql://localhost:3307/advjava?autoReconnect=true&useSSL=false";
			//String user="root";
			//String dbpassword = "tiger";
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			
			Connection con = DriverManager.getConnection(dbproperties.URL,dbproperties.USER,dbproperties.DBPASSWORD);
			
			out.println("connected");
			
			PreparedStatement ps = con.prepareStatement("insert into userdetails values(?,?,?,?)");
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, gender);
			ps.setString(4, address);
			int result = ps.executeUpdate();
			out.print(result);
			
			if(result>0) {
				out.print("Registered Successfully");
			}
			else {
				out.print("something went wrong");
			}
			
			
		}
		catch(Exception e){
			
			System.out.println(e);
			
		}
		
		
		
	
	}

}
