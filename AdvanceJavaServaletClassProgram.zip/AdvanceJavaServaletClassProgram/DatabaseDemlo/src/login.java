

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		

		
		
try {
			
			//String url ="jdbc:mysql://localhost:3307/advjava?autoReconnect=true&useSSL=false";
			//String user="root";
			//String dbpassword = "tiger";
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			
			Connection con = DriverManager.getConnection(dbproperties.URL,dbproperties.USER,dbproperties.DBPASSWORD);
			
			out.println("connected");
			
			PreparedStatement ps = con.prepareStatement("select * from userdetails where username=? and password=?");
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			
			int temp=0;
			while(rs.next()) {
				temp=1;
			}
			if(temp==0) {
				out.print("you have not registered....please register");
				RequestDispatcher rd = request.getRequestDispatcher("index.html");
				rd.include(request, response);
				
				
			}
			else {
				RequestDispatcher rd = request.getRequestDispatcher("welcome.html");
				rd.forward(request, response);
			}
				
			}
			catch(Exception e) {
				System.out.println(e);
			}

		
		
	}

}
