public interface dbproperties{
	public static final String URL ="jdbc:mysql://localhost:3306/advjava?autoReconnect=true&useSSL=false";
	public static final String USER ="root";
	public static final String DBPASSWORD="tiger";
}