

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class tables
 */
@WebServlet("/tablesgenerate")
public class tables extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		
		int num1 = Integer.parseInt(request.getParameter("tablesnumber"));
		int num2 = Integer.parseInt(request.getParameter("limit"));
		
		for(int i=1;i<=num2;i++) {
			out.println(""+i+"*" + ""+num1+"="+i*num1);
			out.println();
		}
		
		
	}

}
