

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class form
 */
@WebServlet("/form")
public class form extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String name = request.getParameter("name1");

		if(password.equals("admin") && username.equals("admin")){
			
			System.out.println("you have logged in");
			out.println("you have logged in <br>");
			out.println("Name:"+name);
			int age = Integer.parseInt(request.getParameter("age"));
			if(age>=18) {
				String gender = request.getParameter("gender");
				String Hobby [] = request.getParameterValues("hobbies");
				
				System.out.println(username);
				System.out.println(password);
				System.out.println(age);
				out.println("<br> Age:"+age);
				System.out.println(gender);
				out.println("<br> Gender:"+gender);
				out.println("<br>Hobbies you selected are :<br>");
				for(String values:Hobby) {
					out.println(values+"<br>");
					System.out.println(values);
					
				}
			}
			else {
				out.print("you are not eligible age should be above 17");
				 RequestDispatcher rd = request.getRequestDispatcher("regis.html");
			      rd.include(request, response);
				
			}
			
			
			
		}
		else {
			System.out.println("login details wrong");
		     out.println("login details wrong");
			 RequestDispatcher rd = request.getRequestDispatcher("regis.html");
		      rd.include(request, response);
			
		}
		
		

		
		
		
		
		
		
	}

}
